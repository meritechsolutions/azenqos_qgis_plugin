import main_window


def test():
    main_window.main()


if __name__ == "__main__":
    test()
